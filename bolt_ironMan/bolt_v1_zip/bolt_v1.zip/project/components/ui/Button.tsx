'use client';

import { cn } from '@/lib/utils';
import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  className?: string;
}

export const Button = ({
  variant = 'primary',
  size = 'md',
  children,
  className,
  ...props
}: ButtonProps) => {
  const getVariantClasses = () => {
    switch (variant) {
      case 'primary':
        return 'bg-[#0066FF] hover:bg-[#00E5E5] text-white border-2 border-[#0066FF] hover:border-[#00E5E5] shadow-[0_0_15px_rgba(0,102,255,0.5)]';
      case 'secondary':
        return 'bg-[#6B2FD9] hover:bg-[#00E5E5] text-white border-2 border-[#6B2FD9] hover:border-[#00E5E5] shadow-[0_0_15px_rgba(107,47,217,0.5)]';
      case 'outline':
        return 'bg-transparent hover:bg-[#0066FF]/10 text-[#0066FF] border-2 border-[#0066FF] hover:border-[#00E5E5] hover:text-[#00E5E5]';
      default:
        return 'bg-[#0066FF] hover:bg-[#00E5E5] text-white';
    }
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'py-2 px-4 text-sm';
      case 'lg':
        return 'py-4 px-8 text-lg';
      default:
        return 'py-3 px-6 text-base';
    }
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={cn(
        'font-bold rounded-md transition-all duration-300 relative overflow-hidden',
        getVariantClasses(),
        getSizeClasses(),
        className
      )}
      {...props}
    >
      <span className="relative z-10">{children}</span>
      <span className="absolute inset-0 bg-gradient-to-r from-[#00E5E5]/0 to-[#00E5E5]/20 opacity-0 hover:opacity-100 transition-opacity duration-300"></span>
    </motion.button>
  );
};