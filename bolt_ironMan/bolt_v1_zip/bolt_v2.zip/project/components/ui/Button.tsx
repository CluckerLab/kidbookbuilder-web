import { cn } from "@/lib/utils";
import { HTMLAttributes } from "react";

interface ButtonProps extends HTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline";
  size?: "sm" | "md" | "lg";
  children: React.ReactNode;
  className?: string;
  type?: "button" | "submit" | "reset";
}

export function Button({
  children,
  variant = "primary",
  size = "md",
  className,
  type = "button",
  ...props
}: ButtonProps) {
  return (
    <button
      type={type}
      className={cn(
        "relative overflow-hidden rounded-md font-medium shadow-md transition-all duration-300 ease-in-out",
        // Base styles
        "inline-flex items-center justify-center",
        // Size variations
        {
          "px-4 py-2 text-sm": size === "sm",
          "px-6 py-3 text-base": size === "md",
          "px-8 py-4 text-lg": size === "lg",
        },
        // Variant styles
        {
          "bg-gradient-to-r from-[#E3000B] to-[#FF4B4B] text-white hover:from-[#FF4B4B] hover:to-[#E3000B]":
            variant === "primary",
          "bg-gradient-to-r from-[#64F3FF] to-[#0B6FFF] text-black hover:from-[#0B6FFF] hover:to-[#64F3FF]":
            variant === "secondary",
          "border-2 border-[#C5C5C5] bg-transparent text-[#C5C5C5] hover:border-[#64F3FF] hover:text-[#64F3FF]":
            variant === "outline",
        },
        className
      )}
      {...props}
    >
      {children}
      {/* Arc reactor glow effect */}
      <span className="absolute inset-0 -z-10 bg-gradient-to-r from-[#64F3FF]/20 to-[#0B6FFF]/20 opacity-0 blur-xl transition-opacity duration-1000 group-hover:opacity-100"></span>
    </button>
  );
}